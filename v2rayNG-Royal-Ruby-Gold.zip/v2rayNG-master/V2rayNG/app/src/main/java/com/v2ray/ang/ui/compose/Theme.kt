package com.v2ray.ang.ui.compose

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.v2ray.ang.AppConfig
import com.v2ray.ang.handler.MmkvManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/*
 * Royal Ruby & Gold theme
 * Inspired by the red/gold artwork: deep ruby surfaces, warm gold accents,
 * soft ivory text, and restrained contrast. Dynamic Android colors are
 * disabled by default so the palette stays consistent.
 */

private val LightColor = lightColorScheme(
    primary = Color(0xFF8F1730),              // Ruby
    onPrimary = Color(0xFFFFF7F2),            // Ivory
    primaryContainer = Color(0xFFFFD9DE),     // Rose blush
    onPrimaryContainer = Color(0xFF3B0712),
    secondary = Color(0xFFC58A22),            // Antique gold
    onSecondary = Color(0xFF2D1A00),
    secondaryContainer = Color(0xFFFFE3A6),   // Champagne
    onSecondaryContainer = Color(0xFF3A2600),
    tertiary = Color(0xFFB54A3B),             // Warm copper-red
    onTertiary = Color(0xFFFFF7F2),
    tertiaryContainer = Color(0xFFFFDAD3),
    onTertiaryContainer = Color(0xFF3F0803),
    error = Color(0xFFBA1A1A),
    errorContainer = Color(0xFFFFDAD6),
    onError = Color(0xFFFFFFFF),
    onErrorContainer = Color(0xFF410002),
    background = Color(0xFFFFF8F5),           // Warm ivory
    onBackground = Color(0xFF24171A),
    surface = Color(0xFFFFF8F5),
    onSurface = Color(0xFF24171A),
    surfaceVariant = Color(0xFFF0DDE0),
    onSurfaceVariant = Color(0xFF5A4147),
    outline = Color(0xFF8C6B72),
    outlineVariant = Color(0xFFD9BEC3),
    inverseSurface = Color(0xFF392C30),
    inverseOnSurface = Color(0xFFFFEDEA),
    inversePrimary = Color(0xFFFFB1BC),
    scrim = Color(0xFF000000),
    surfaceTint = Color(0xFF8F1730),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFFFF1F0),
    surfaceContainer = Color(0xFFFFE9E8),
    surfaceContainerHigh = Color(0xFFFFE1E2),
    surfaceContainerHighest = Color(0xFFF9D9DC),
)

private val DarkColor = darkColorScheme(
    primary = Color(0xFFFFB0BB),              // Soft ruby highlight
    onPrimary = Color(0xFF5D0018),
    primaryContainer = Color(0xFF8F1730),     // Ruby
    onPrimaryContainer = Color(0xFFFFDADF),
    secondary = Color(0xFFFFC94F),            // Signature gold
    onSecondary = Color(0xFF3B2600),
    secondaryContainer = Color(0xFF765300),   // Deep gold
    onSecondaryContainer = Color(0xFFFFE4A8),
    tertiary = Color(0xFFFF9B89),             // Warm coral
    onTertiary = Color(0xFF4F1008),
    tertiaryContainer = Color(0xFF7A251B),
    onTertiaryContainer = Color(0xFFFFDAD3),
    error = Color(0xFFFFB4AB),
    errorContainer = Color(0xFF93000A),
    onError = Color(0xFF690005),
    onErrorContainer = Color(0xFFFFDAD6),
    background = Color(0xFF12090C),            // Almost black ruby
    onBackground = Color(0xFFF6E9E8),
    surface = Color(0xFF180C10),
    onSurface = Color(0xFFF6E9E8),
    surfaceVariant = Color(0xFF3B1C23),
    onSurfaceVariant = Color(0xFFD8BFC4),
    outline = Color(0xFF9E737B),
    outlineVariant = Color(0xFF5A3039),
    inverseSurface = Color(0xFFF6E9E8),
    inverseOnSurface = Color(0xFF24171A),
    inversePrimary = Color(0xFF8F1730),
    scrim = Color(0xFF000000),
    surfaceTint = Color(0xFFFFB0BB),
    surfaceContainerLowest = Color(0xFF0D0608),
    surfaceContainerLow = Color(0xFF170A0E),
    surfaceContainer = Color(0xFF1E0E13),
    surfaceContainerHigh = Color(0xFF28131A),
    surfaceContainerHighest = Color(0xFF321820),
)

// Semantic colors
val colorPing = Color(0xFFFFC94F)             // Gold = healthy/connected
val colorPingRed = Color(0xFFFF5570)          // Ruby = error/poor
val colorConfigType = Color(0xFFFFC94F)       // Gold
val colorFabActive = Color(0xFFC51F3A)        // Ruby
val colorFabInactiveLight = Color(0xFF9C8A8E)
val colorFabInactiveDark = Color(0xFF6C4B54)
val dividerColorLight = Color(0xFFE7D2D5)
val dividerColorDark = Color(0xFF4A242D)

// Toast colors
val toastNormalBgLight = Color(0xD93B1F27)
val toastNormalBgDark = Color(0xE63B151F)
val toastSuccessBg = Color(0xE6A87310)        // Gold
val toastErrorBg = Color(0xE6B5122B)          // Ruby
val toastInfoBg = Color(0xE65D315F)           // Plum
val toastIconCircleBg = Color(0x33FFFFFF)
val toastTextColor = Color.White

object ThemeManager {
    private val _themeMode = MutableStateFlow(
        MmkvManager.decodeSettingsString(AppConfig.PREF_UI_MODE_NIGHT, "0") ?: "0"
    )
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    // Keep Android dynamic colors off by default so the Royal Ruby & Gold
    // palette remains stable across devices.
    private val _dynamicColorEnabled = MutableStateFlow(
        MmkvManager.decodeSettingsBool(AppConfig.PREF_DYNAMIC_COLOR, false)
    )
    val dynamicColorEnabled: StateFlow<Boolean> = _dynamicColorEnabled.asStateFlow()

    fun setThemeMode(mode: String) {
        MmkvManager.encodeSettings(AppConfig.PREF_UI_MODE_NIGHT, mode)
        _themeMode.value = mode
    }

    fun setDynamicColorEnabled(enabled: Boolean) {
        MmkvManager.encodeSettings(AppConfig.PREF_DYNAMIC_COLOR, enabled)
        _dynamicColorEnabled.value = enabled
    }

    fun refresh() {
        _themeMode.value =
            MmkvManager.decodeSettingsString(AppConfig.PREF_UI_MODE_NIGHT, "0") ?: "0"
        _dynamicColorEnabled.value =
            MmkvManager.decodeSettingsBool(AppConfig.PREF_DYNAMIC_COLOR, false)
    }
}

@Composable
fun resolveDarkTheme(): Boolean {
    val mode by ThemeManager.themeMode.collectAsState()
    return when (mode) {
        "1" -> false
        "2" -> true
        else -> isSystemInDarkTheme()
    }
}

val LocalDarkTheme = compositionLocalOf { false }

@Composable
fun AppTheme(
    darkTheme: Boolean = resolveDarkTheme(),
    content: @Composable () -> Unit
) {
    val dynamicColor by ThemeManager.dynamicColorEnabled.collectAsState()
    val context = LocalContext.current

    // Dynamic color is intentionally still supported; it is simply off by
    // default for this custom fork.
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (darkTheme) {
                androidx.compose.material3.dynamicDarkColorScheme(context)
            } else {
                androidx.compose.material3.dynamicLightColorScheme(context)
            }
        }
        darkTheme -> DarkColor
        else -> LightColor
    }

    val snackbarController = rememberAppSnackbarController()
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val activity = view.context as? Activity ?: return@SideEffect
            val window = activity.window
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !darkTheme
                isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    CompositionLocalProvider(
        LocalDarkTheme provides darkTheme,
        LocalAppSnackbar provides snackbarController
    ) {
        MaterialTheme(
            colorScheme = colorScheme
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                AppSnackbarBridge(controller = snackbarController)
                content()
                AppSnackbarHost(hostState = snackbarController.hostState)
            }
        }
    }
}
